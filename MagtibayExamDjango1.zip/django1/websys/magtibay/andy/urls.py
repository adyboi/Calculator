from django.urls import path
from django.urls import path

from . import views 
from andy.views import classview 
app_name = 'andy'
urlpatterns = [
    path('function', views.functionview, name= 'functionview'),
     path('class', classview.as_view(), name= 'classview'),
]